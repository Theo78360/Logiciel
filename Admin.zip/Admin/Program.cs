﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Login MonFormLogin = new Login();

            MonFormLogin.ShowDialog();
            if (MonFormLogin.DialogResult == DialogResult.OK)
            {
                //String NiveauUtilisateur = MonFormLogin.StrLevel;
                MonFormLogin.Close();
                //Application.Run(new Form1(NiveauUtilisateur));
            }
            else
                MonFormLogin.Close();
            MessageBox.Show("Au revoir");

            Console.WriteLine("sha1 " + SHA.petitsha("abc"));

            Console.WriteLine("md5 " + SHA.MakeMD5Hash("abc"));

            Console.WriteLine("sha256 " + SHA.GenerateSHA256String("abc"));

            Console.WriteLine("sha512 " + SHA.GenerateSHA512String("abc"));
        }
    }
}
