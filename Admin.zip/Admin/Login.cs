﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Admin
{
    public partial class Login : Form
    {
        string _connectionString = "server=127.0.0.1;user id = root; persistsecurityinfo=True;database=ppe";
        public Login()
        {
            InitializeComponent();
        }

        private void bta_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void btv_Click(object sender, EventArgs e)
        {
          

            MySqlConnection conn = new MySqlConnection(_connectionString);
           try

            {
                
                string query = (" SELECT login, mdp FROM user WHERE login='" + ltb.Text + "'AND mdp= '" + mtb.Text + "';");
                MySqlCommand cmd = new MySqlCommand(query, conn);
                conn.Open();
                MySqlDataReader rdr = cmd.ExecuteReader();
                string pass, user;
                user = ltb.Text;
                pass = mtb.Text;
                while (rdr.Read())
                {
                    if (rdr["login"].ToString() != ltb.Text && rdr["mdp"].ToString() != mtb.Text)
                    {
                        label1.Text = "Nom utilisateur ou mot de passe invalide";
                        conn.Close();
                    }


                    else
                    {
                        
                            if (rdr["login"].ToString() == ltb.Text && rdr["mdp"].ToString() == mtb.Text)
                            {
                            this.DialogResult = DialogResult.OK;
                        }

                        }
                    }

                conn.Close();


            }
            
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            conn.Close(); //Fermer la connexion
            
        }
        public string pass;
        private MySqlCommand reader;

        private void AttribuerMdp()
        {
            pass = SHA.MakeMD5Hash(mtb.Text);
        }
    }

        
          }
    
    

